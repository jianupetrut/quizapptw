package ro.ase.codinquiz.quizapplication.Main.Student;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import ro.ase.codinquiz.quizapplication.R;

public class StudentMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_main);
    }
}
