package ro.ase.codinquiz.quizapplication.Main.Teacher;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import ro.ase.codinquiz.quizapplication.R;

public class TeacherConfigureTestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_configure_test);
    }
}
